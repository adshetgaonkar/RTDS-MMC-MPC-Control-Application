/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: VDC_cont_4T_V3_data.c
 *
 * Code generated for Simulink model 'VDC_cont_4T_V3'.
 *
 * Model version                  : 1.33
 * Simulink Coder version         : 9.2 (R2019b) 18-Jul-2019
 * C/C++ source code generated on : Wed Aug  3 19:21:16 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "VDC_cont_4T_V3.h"
#include "VDC_cont_4T_V3_private.h"

/* Block parameters (default storage) */
Parameters_VDC_cont_4T_V3 VDC_cont_4T_V3_P = {
  /* Expression: 0.0
   * Referenced by: '<Root>/Delay'
   */
  0.0,

  /* Expression: 0.0
   * Referenced by: '<Root>/Delay2'
   */
  0.0,

  /* Expression: 0.0
   * Referenced by: '<Root>/Delay1'
   */
  0.0
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
