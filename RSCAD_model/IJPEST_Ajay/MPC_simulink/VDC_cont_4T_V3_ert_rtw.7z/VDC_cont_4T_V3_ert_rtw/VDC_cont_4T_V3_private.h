/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: VDC_cont_4T_V3_private.h
 *
 * Code generated for Simulink model 'VDC_cont_4T_V3'.
 *
 * Model version                  : 1.33
 * Simulink Coder version         : 9.2 (R2019b) 18-Jul-2019
 * C/C++ source code generated on : Wed Aug  3 19:21:16 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_VDC_cont_4T_V3_private_h_
#define RTW_HEADER_VDC_cont_4T_V3_private_h_
#include "rtwtypes.h"
#endif                                /* RTW_HEADER_VDC_cont_4T_V3_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
